<?php
    echo '
    <footer>
        <p>Designed by DD</p>
        <hr>
        <p>@Projekt WSIiZ</p>
    </footer>';
?>