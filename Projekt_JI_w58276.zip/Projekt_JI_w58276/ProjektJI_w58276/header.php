<?php
    echo '
    <header>
        <img id="headerImg" src="headerIco.png"/>
        <img id="headerTxt" src="text.png"/>
    </header>';
?>